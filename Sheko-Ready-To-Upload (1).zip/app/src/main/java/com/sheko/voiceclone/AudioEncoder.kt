package com.sheko.voiceclone

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer

object AudioEncoder {
    fun wavToM4a(wav: File, out: File, bitrate: Int = 96000): Boolean {
        RandomAccessFile(wav, "r").use { raf ->
            val header = ByteArray(44)
            raf.readFully(header)
            if (String(header, 0, 4) != "RIFF" || String(header, 8, 4) != "WAVE") return false
            val channels = le16(header, 22)
            val sampleRate = le32(header, 24)
            val bits = le16(header, 34)
            if (bits != 16) return false

            val codec = MediaCodec.createEncoderByType("audio/mp4a-latm")
            val format = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channels)
            format.setInteger(MediaFormat.KEY_AAC_PROFILE, 2)
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var track = -1
            var started = false
            var ptsUs = 0L
            val frameBytes = 2048
            val pcm = ByteArray(frameBytes)
            var inputDone = false
            var outputDone = false

            try {
                while (!outputDone) {
                    if (!inputDone) {
                        val inIndex = codec.dequeueInputBuffer(10000)
                        if (inIndex >= 0) {
                            val input = codec.getInputBuffer(inIndex)!!
                            input.clear()
                            val n = raf.read(pcm)
                            if (n > 0) {
                                input.put(pcm, 0, n)
                                val samples = n / (2 * channels)
                                val duration = samples * 1_000_000L / sampleRate
                                codec.queueInputBuffer(inIndex, 0, n, ptsUs, 0)
                                ptsUs += duration
                            } else {
                                codec.queueInputBuffer(inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            }
                        }
                    }

                    val info = MediaCodec.BufferInfo()
                    var outIndex = codec.dequeueOutputBuffer(info, 10000)
                    while (outIndex >= 0) {
                        val outBuf = codec.getOutputBuffer(outIndex)!!
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            info.size = 0
                        }
                        if (info.size > 0) {
                            if (!started) {
                                val newFormat = codec.outputFormat
                                track = muxer.addTrack(newFormat)
                                muxer.start()
                                started = true
                            }
                            outBuf.position(info.offset)
                            outBuf.limit(info.offset + info.size)
                            muxer.writeSampleData(track, outBuf, info)
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        outIndex = codec.dequeueOutputBuffer(info, 0)
                    }
                }
            } finally {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
                if (started) try { muxer.stop() } catch (_: Exception) {}
                muxer.release()
            }
            return out.exists() && out.length() > 0
        }
    }

    private fun le16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xff) or ((b[o+1].toInt() and 0xff) shl 8)

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xff) or
        ((b[o+1].toInt() and 0xff) shl 8) or
        ((b[o+2].toInt() and 0xff) shl 16) or
        ((b[o+3].toInt() and 0xff) shl 24)
}
