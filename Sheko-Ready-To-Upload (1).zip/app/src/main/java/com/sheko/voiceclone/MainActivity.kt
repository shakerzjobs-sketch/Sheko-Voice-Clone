package com.sheko.voiceclone

import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var lastWav: File? = null
    private var lastM4a: File? = null
    private lateinit var status: TextView
    private lateinit var generate: Button
    private lateinit var play: Button
    private lateinit var whats: Button
    private lateinit var share: Button
    private lateinit var save: Button
    private lateinit var seek: SeekBar
    
    // عنوان السيرفر المحلي (استبدله بـ IP جهازك إذا كنت تجرب على موبايل حقيقي)
    private val SERVER_URL = "http://10.0.2.2:8000/clone" 

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.tvStatus)
        generate = findViewById(R.id.btnGenerate)
        play = findViewById(R.id.btnPlay)
        whats = findViewById(R.id.btnWhatsApp)
        share = findViewById(R.id.btnShare)
        save = findViewById(R.id.btnSave)
        seek = findViewById(R.id.seek)

        generate.setOnClickListener { generateAudio() }
        play.setOnClickListener { playLast() }
        whats.setOnClickListener { shareAudio(true) }
        share.setOnClickListener { shareAudio(false) }
        save.setOnClickListener { saveWavCopy() }

        findViewById<Button>(R.id.btnReference).setOnClickListener {
            val ref = MediaPlayer.create(this, R.raw.reference_voice)
            ref?.apply {
                setOnCompletionListener { it.release() }
                start()
            }
        }

        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser && player != null) player!!.seekTo(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun generateAudio() {
        val text = findViewById<EditText>(R.id.etText).text.toString().trim()
        if (text.isEmpty()) { status.text = "اكتب النص أولًا"; return }

        generate.isEnabled = false
        status.text = "جاري التواصل مع محرك XTTS v2..."

        // استخراج ملف المرجع من الموارد
        val refFile = File(cacheDir, "reference.wav")
        resources.openRawResource(R.raw.reference_voice).use { input ->
            refFile.outputStream().use { output -> input.copyTo(output) }
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("text", text)
            .addFormDataPart("language", "ar")
            .addFormDataPart("file", "reference.wav", refFile.asRequestBody("audio/wav".toMediaType()))
            .build()

        val request = Request.Builder()
            .url(SERVER_URL)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    status.text = "فشل الاتصال بالسيرفر: ${e.message}"
                    generate.isEnabled = true
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    runOnUiThread {
                        status.text = "خطأ من السيرفر: ${response.code}"
                        generate.isEnabled = true
                    }
                    return
                }

                val dir = File(filesDir, "audio").apply { mkdirs() }
                lastWav = File(dir, "sheko_${System.currentTimeMillis()}.wav")
                
                response.body?.byteStream()?.use { input ->
                    lastWav!!.outputStream().use { output -> input.copyTo(output) }
                }

                runOnUiThread { finishGeneration() }
            }
        })
    }

    private fun finishGeneration() {
        val wav = lastWav ?: return
        status.text = "تم التوليد بنجاح! جاري التجهيز..."
        
        // تحويل الصوت إلى M4A للمشاركة (اختياري)
        Thread {
            val m4a = File(wav.parentFile, wav.nameWithoutExtension + ".m4a")
            val ok = try { AudioEncoder.wavToM4a(wav, m4a, 96000) } catch (_: Exception) { false }
            runOnUiThread {
                lastM4a = if (ok) m4a else null
                status.text = "الصوت جاهز الآن"
                generate.isEnabled = true
                play.isEnabled = true
                whats.isEnabled = ok
                share.isEnabled = ok
                save.isEnabled = true
            }
        }.start()
    }

    // ... (بقية الدوال playLast و shareAudio و saveWavCopy تبقى كما هي)
}
